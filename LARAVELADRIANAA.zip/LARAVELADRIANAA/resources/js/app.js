import './bootstrap';
import.meta.global(["../images/**"]);
